apt-get autoremove --purge -y python-mysqldb mysql-server

apt-get autoremove --purge -y python-mysqldb mysql-client curl
apt-get autoremove --purge -y keystone

apt-get autoremove --purge -y python-mysqldb mysql-client curl
apt-get autoremove --purge -y glance 

apt-get autoremove --purge -y ntp 
apt-get autoremove --purge -y rabbitmq-server
apt-get autoremove --purge -y python-mysqldb mysql-client curl
apt-get autoremove --purge -y nova-api nova-scheduler nova-cert nova-consoleauth

apt-get autoremove --purge -y python-mysqldb mysql-client curl
apt-get autoremove --purge -y nova-compute nova-network nova-vncproxy

apt-get autoremove --purge -y python-mysqldb mysql-client curl
apt-get autoremove --purge -y memcached libapache2-mod-wsgi openstack-dashboard
